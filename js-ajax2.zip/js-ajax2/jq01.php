<?php
	echo 'alert("高高高，欧蕾欧蕾欧蕾！")'

?>
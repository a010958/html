<?php
	echo '{"name":"gege","sex":"man","age":99}';
?>
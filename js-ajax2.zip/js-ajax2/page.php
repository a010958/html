<?php

	echo '<table border="1" width="400">
				<tr>
					<td>用户名：</td>
					<td><input type="text" name="user" value="大傻" /></td>
				</tr>
				<tr>
					<td>密码：</td>
					<td><input type="password" name="owd" value="你是傻子这事尼玛知道吗？" /></td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="submit" value="注册"/>
						<input type="reset" value="重置"/>
					</td>
				</tr>
			</table>'


?>

<?php
	
	//输出get请求
	//echo $_GET['age'];

	//输出post请求
	echo $_POST['age'];

?>
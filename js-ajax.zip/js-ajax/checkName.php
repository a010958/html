<?php

	//获取get发送来的用户名
	$username = $_GET['username'];
	
	//检测是否存在（连接数据库验证）
	if($username == '二大爷'){
		echo 1;//用户名存在返回1
	}else{
		echo 0;//用户名不存在返回0
	}

?>

//ajax工具对象：1.兼容问题  2.便捷问题


function Ajax(){
	
	//1.兼容问题 xhr对象
	var xhr = null;
	
	if(window.XMLHttpRequest){//检测是否有XMLHttpRequest构造方法
		//使用XMLHttpRequest构造方法创建xhr对象
		xhr = new XMLHttpRequest();
	}else if(window.ActiveXObject){//检测是否可以使用低版本ie的ActiveXObject
		//使用ActiveXObject来创建xhr对象
		//下面的数组为ie可能使用的版本名称
		var versions = ['Microsoft.XMLHTTP', 'MSXML.XMLHTTP', 'Microsoft.XMLHTTP', 'Msxml2.XMLHTTP.7.0', 'Msxml2.XMLHTTP.6.0', 'Msxml2.XMLHTTP.5.0', 'Msxml2.XMLHTTP.4.0', 'MSXML2.XMLHTTP.3.0', 'MSXML2.XMLHTTP'];
		//遍历数组测试是否可以使用
		for(var i=0;i<versions.length;i++){
			//尝试创建
			xhr = new ActiveXObject(versions[i]);
			//检测是否创建成功
			if (xhr){
				break;
			}
		}
	}else{//都无法使用，就不能用ajax
		return false;
	}
	
	
	//继续简化ajax第四步
	function checkAndUse(func){
		
		xhr.onreadystatechange=function(){
			if(xhr.readyState==4){
				if(xhr.status == 200){
					//使用响应的数据
					func(xhr.responseText)
				}
			}
			
		}
	}
	
	//定义一个get请求的内部函数
	function ajaxGET(url,callback){
		//1.创建xhr对象（已经在兼容性位置解决）
		//2.建立连接
		xhr.open('get',url);
		//3.发送数据
		xhr.send(null);
		//4.检测请求与响应
		checkAndUse(callback);
	}
	
	
	//定义一个post请求的内部函数
	function ajaxPOST(url,data,callback){
		//1.创建xhr对象（已经在兼容性位置解决）
		//2.建立连接
		xhr.open('post',url);
		xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		//3.发送数据
		xhr.send(data);
		//4.检测请求与响应
		checkAndUse(callback);
	}
	
	//返回值-2.便捷问题 (闭包实例)
	return {
		//ajax的功能对象
		get:ajaxGET,//实现ajax的get异步传输
		post:ajaxPOST//实现ajax的post异步传输
	}
}

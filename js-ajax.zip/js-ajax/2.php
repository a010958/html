<?php

	echo '{"name":"丛浩","age":"18","sex":"男","length":"23cm"}'

?>